import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { MaintabsComponent } from '../maintabs/maintabs.component';



@NgModule({
    declarations: [
        //MaintabsComponent,
      
  
    ],
    imports: [
      CommonModule,
      //MaintabsComponent 
    ]
  })
export class AdminLandingModule { }
