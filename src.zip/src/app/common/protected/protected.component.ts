import { Component } from '@angular/core';

@Component({
  selector: 'app-secure',
  template: `<h2>PROTECTED!</h2>`,
})
export class ProtectedComponent {}
