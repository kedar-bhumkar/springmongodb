import { Component } from '@angular/core';

@Component({
  selector: 'app-portalselector',
  templateUrl: './portalselector.component.html',
  styleUrls: ['./portalselector.component.css']
})
export class PortalselectorComponent {

}
